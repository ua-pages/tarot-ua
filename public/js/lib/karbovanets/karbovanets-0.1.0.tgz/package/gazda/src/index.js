export const versiya = '0.0.1'

export { default as Marshrutyzator } from './router.js'

const gazda = { versiya, Marshrutyzator }

export default gazda
